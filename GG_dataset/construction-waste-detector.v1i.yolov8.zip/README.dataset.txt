# construction-waste-detector > 2025-04-10 10:33am
https://universe.roboflow.com/garbageguard/construction-waste-detector

Provided by a Roboflow user
License: CC BY 4.0

